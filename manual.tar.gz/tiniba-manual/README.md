Documentation for TINIBA
========================
TINIBA is a tool written in bash, perl, and fortran to do ab initio calculations of optical responses based on the popular ABINIT. This repo contains the documentation for using it!

This document is a severe work in progress and is just the very first draft of what the final documentation will look like.
